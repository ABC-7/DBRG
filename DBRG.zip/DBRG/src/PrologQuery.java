import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.jpl7.Query;
import org.jpl7.Term;

import ReqStructure.*;

public class PrologQuery {

	public static ArrayList<Requirement> generateComponentsBasedRequirements(int reqCount, String Senario, boolean multilevel){
		
		File f = new File("src/Dic.Pl");
		System.out.println(f.getAbsolutePath());
		if(multilevel) {
			Query q = new Query("consult('src/SentenceGeneratorComplexSenarios.Pl')");
			System.out.println((q.hasSolution() ? "succeeded" : "failed"));
			
			//Senario = "\"[inReq([inComp('cond', E1, V1, Rel1, 'no', 1), inComp('act', E2, V2,Rel2, 'no', 1)], ['','', '', '', ''] , Req1_Text), inReq([inComp('cond', E2, V2, Rel2, 'no', 1),inComp('act', E1, V1, Rel1, 'no', 1)], ['','','','',''] , Req2_Text), inReq([inComp('act', E1, V1, Rel1, 'no', 1)], ['','','','',''] , Req3_Text)]\"";
			
			//String query = "generateSentences("+ reqCount+", "+ "ReqL, FreqL, " + Setting + ", " + Redundant +")";
			String query = "generateSemiformalSenarios(\""+ f.getAbsolutePath()+"\", 1, "+ Senario +", "+ "ReqL)";
			System.out.println(query);
			
			
			do {
				q= new Query(query);
			}while(q == null);
			
			Term requiremens = (Term) q.oneSolution().get("ReqL");
			ArrayList<Requirement> reqs = convertPrologComponents(requiremens);
			return reqs;
		} else {
			f = new File("src/LexicalWords.Pl");
			Query q = new Query("consult('src/FaultyReqV2.Pl')");
			System.out.println((q.hasSolution() ? "succeeded" : "failed"));
			
			//Senario = "\"[inReq([inComp('cond', E1, V1, Rel1, 'no', 1), inComp('act', E2, V2,Rel2, 'no', 1)], ['','', '', '', ''] , Req1_Text), inReq([inComp('cond', E2, V2, Rel2, 'no', 1),inComp('act', E1, V1, Rel1, 'no', 1)], ['','','','',''] , Req2_Text), inReq([inComp('act', E1, V1, Rel1, 'no', 1)], ['','','','',''] , Req3_Text)]\"";
			
			//String query = "generateSentences("+ reqCount+", "+ "ReqL, FreqL, " + Setting + ", " + Redundant +")";
			Senario = Senario.replaceAll("inReq\\(", "req(");
			Senario = Senario.replaceAll("inComp\\(", "comp(");
			Senario = Senario.substring(1, Senario.length()-2);
			Senario = Senario + "|RemList]";
			
			String query = "generateFaulty(\""+ f.getAbsolutePath()+"\","+ reqCount+", "+ Senario +", "+ "ReqL)";
			System.out.println(query);
			
			
			do {
				q= new Query(query);
			}while(q == null);
			
			Term requiremens = (Term) q.oneSolution().get("ReqL");
			ArrayList<Requirement> reqs = convertPrologSingleLevelComponents(requiremens);
			return reqs;
		}
		
		
		//updateMeasures(q.oneSolution().get("FreqL"), measures);
		//ArrayList<ArrayList<ReqComponent>> comps = convertPrologComponents(requiremens);
		
		//return filterQueryOutput(requiremens.toString());
		//System.out.println(convertQueryOutputToarrayList(getPrologAtomicString(requiremens)));
		
		//return getPrologAtomicString(requiremens);
	}
	
	private static ArrayList<Requirement> convertPrologSingleLevelComponents(Term requiremens) {
		ArrayList<ReqComponent> comps;
		ArrayList<Requirement> reqs = new ArrayList<Requirement>();
		ReqComponent component;
		Requirement req;
		String text;
		int i = 1;
		for (Term  reqCompList: requiremens.toTermArray()) {
			
			if(!reqCompList.isCompound())
				continue;
			while(!reqCompList.name().equals("req")) 
				reqCompList = reqCompList.arg(1);
			req = new Requirement();
			comps = new ArrayList<ReqComponent>();
			if(reqCompList.name().equals("end_of_file"))
				break;
			
			Term[] compArr = reqCompList.arg(2).toTermArray();
			//for (int j = 1; j < 6; j++) {
				//Term[] NcompArr = compArr.arg(j).toTermArray();
				for (Term  c: compArr) {
					if(!c.isCompound())
						continue;
					while(!c.name().equals("comp")) 
						c = c.arg(1);
					component = new ReqComponent();
					component.setId(getPrologAtomicString(c.arg(1)));
					component.setType(getPrologAtomicString(c.arg(2)));
					Term[] args = c.arg(3).toTermArray();
					for (int k=0; k<5; k++) {
						component.addArgument(getPrologAtomicString(args[k]));
						
					}
					component.setVerb(getPrologAtomicString(args[5]));
					args = args[6].toTermArray();
					for (Term  complement: args) {
						if(!complement.isCompound())
							continue;
						while(!complement.name().equals("prep")) 
							complement = complement.arg(1);
						component.addArgument(getPrologAtomicString(complement.arg(1)));
						component.addArgument(getPrologAtomicString(complement.arg(2)));
					}
					component.setCompText(getPrologAtomicString(c.arg(4)));
					comps.add(component);
			//	}
				
			}
			String t = "";
			Term[] coordRel = reqCompList.arg(3).toTermArray();
			for (Term tt : coordRel) {
				t += tt.toString() + ",";
			}
			req.setCoordination( "[" + t.substring(0, t.length()-1) + "]");

			req.setId(getPrologAtomicString(reqCompList.arg(1)));
			req.setComponents(comps);
			req.setReqText(getPrologAtomicString(reqCompList.arg(4)));	
			i++;
			reqs.add(req);
			
		}
			
		return reqs;
	}

	private static ArrayList<Requirement> convertPrologComponents(Term requiremens) {
		
		ArrayList<SubComponent> subComponents;
		ArrayList<ArrayList<ReqComponent>> res = new ArrayList<ArrayList<ReqComponent>>();
		ArrayList<ReqComponent> comps;
		ArrayList<Requirement> reqs = new ArrayList<Requirement>();
		ReqComponent component;
		Requirement req;
		String text;
		int i = 1;
		for (Term  senarios: requiremens.toTermArray()) {
			for (Term  reqCompList: senarios.arg(1).toTermArray()) {
			if(!reqCompList.isCompound())
				continue;
			while(!reqCompList.name().equals("inReq")) 
				reqCompList = reqCompList.arg(1);
			req = new Requirement();
			comps = new ArrayList<ReqComponent>();
			if(reqCompList.name().equals("end_of_file"))
				break;
			
			Term[] compArr = reqCompList.arg(1).toTermArray();
			for (Term  c: compArr) {
				if(!c.isCompound())
					continue;
				while(!c.name().equals("inComp")) 
					c = c.arg(1);
				component = new ReqComponent();
				component.setType(getPrologAtomicString(c.arg(1)));
				component.addArgument(getPrologAtomicString(c.arg(2)));
				component.addArgument(getPrologAtomicString(c.arg(3)));
				component.setVerb(getPrologAtomicString(c.arg(4)));
				String t= getPrologAtomicString(c.arg(5));
				if(t.equals("no"))
					component.setNegated(false);
				else
					component.setNegated(true);
				component.setId(getPrologAtomicString(c.arg(6)));
				
				comps.add(component);
			}
			String t = "";
			Term[] coordRel = reqCompList.arg(2).toTermArray();
			for (Term tt : coordRel) {
				t += tt.toString() + ",";
			}
			req.setCoordination( "[" + t.substring(0, t.length()-1) + "]");

			req.setId("R"+i);
			req.setComponents(comps);
			req.setReqText(getPrologAtomicString(reqCompList.arg(3)));	
			i++;
			reqs.add(req);
			}
		}
			
		return reqs;
	}

	private static String getPrologAtomicString(Term text) {
		String plainTerm = text.toString().replace("'", "");
		plainTerm = plainTerm.replace("(", "");
		plainTerm = plainTerm.replace(")", "");
		plainTerm = plainTerm.replace("+", "");
		plainTerm = plainTerm.replace(",", "");
		plainTerm = plainTerm.replace("\\s+", " ");
		return plainTerm;
	}
	
}
