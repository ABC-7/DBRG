package ReqStructure;

import java.util.ArrayList;


public class Requirement {
	private String reqText;
	
	private String coordination;
	public String getCoordination() {
		return coordination;
	}
	public void setCoordination(String coordination) {
		this.coordination = coordination;
	}


	private String Id;
	

	private ArrayList<ReqComponent> components;
	

	public String getReqText() {
		return reqText;
	}
	public void setReqText(String reqText) {
		this.reqText = reqText;
	}
	public void setId(String string) {
		Id = string;
	}
	public String getId() {
		return Id;
	}

	public ArrayList<ReqComponent> getComponents() {
		return components;
	}

	public void setComponents(ArrayList<ReqComponent> res) {
		this.components = res;
	}
	

	@Override
	public String toString() {
		
		return "inReq("+ Id + ", "+ components + ", " + coordination + ", " + reqText + ")";
	}
}
