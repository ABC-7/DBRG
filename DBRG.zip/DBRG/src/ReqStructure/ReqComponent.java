package ReqStructure;

import java.util.ArrayList;



enum ComponentType { Condition, Trigger, Action, ActionScope, PreConditionalScope, ReqScope;
	public static ComponentType getCompType(String typeCode) {
		switch(typeCode.toLowerCase()) {
		
		case "cond":
			return ComponentType.Condition;
		case "act":
			return ComponentType.Action;
		case "trig":
			return ComponentType.Trigger;
		case "condscope":
			return ComponentType.ReqScope;
		case "precondscope":
			return ComponentType.PreConditionalScope;
		case "actscope":
			return ComponentType.ActionScope;
		}
		return null;
	}	
	@Override
	public String toString() {
		switch (this) {
		  case Condition: return "cond";
	      case Trigger: return "trig";
	      case Action: return "act";
	      case ActionScope: return "actScope";
	      case PreConditionalScope: return "preScope";
	      default: throw new IllegalArgumentException();
		}
	}
}

public class ReqComponent{
	
	
	String compText;
	String Id;
	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	boolean negated;
	public boolean isNegated() {
		return negated;
	}

	public void setNegated(boolean negated) {
		this.negated = negated;
	}

	ArrayList<String> args;
	ArrayList<SubComponent> subComponents;
	String verb;
	public String getVerb() {
		return verb;
	}

	public void setVerb(String verb) {
		this.verb = verb;
	}

	ComponentType type;
	
	
	public ReqComponent() {
		super();
		subComponents = new ArrayList<SubComponent>();
		args = new ArrayList<String>();
	}
	
	public ReqComponent(String compText, int sIndex) {
		super();
		subComponents = new ArrayList<SubComponent>();
		this.compText = compText;
	}
	
	public String getCompText() {
		return compText;
	}
	
	public void setCompText(String compText) {
		this.compText = compText;
	}
	
	public ComponentType getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = ComponentType.getCompType(type);
	}
	
	public ArrayList<SubComponent> getSubComponents() {
		return subComponents;
	}
	
	public void setSubComponents(ArrayList<SubComponent> subComponents) {
		this.subComponents = subComponents;
	}
	public void addSubComponents(SubComponent subComponent) {
		this.subComponents.add(subComponent);
	}
	
	public String getSubj() {
		String subj = "";
		if(args.size() >2)
			for (int i = 0; i < 5; i++) {
				subj += args.get(i) + " ";
			}
		else 
			subj = args.get(0);
		return subj;
	}
	public String getComplement() {
		String comp = "";
		if(args.size() >2)
			for (int i = 5; i < args.size(); i++) {
				comp += args.get(i) + " ";
			}
		else 
			comp = args.get(1);
		return comp;
	}
	public ArrayList<String> getArguments() {
		return args;
	}
	public void setArguments(ArrayList<String> args) {
		this.args = args;
	}
	public void addArgument(String arg) {
		this.args.add(arg);
	}
	
	
	public boolean isAction() {
		return type.equals(ComponentType.Action);
	}
	
	public String toString() {
		return "inComp(" + Id + ", "+  type.toString() + ", " + getCompArgs() + ")";
	}

	private String getCompArgs() {
		String text = "'";
		if(args.size() > 2) {
			text += args.get(0) + "', '" + args.get(1) + "', '" + args.get(2) + "', '" + args.get(3) + "', '" + args.get(4) + "', '" +  verb  + "'";
			for (int i = 5; i < args.size(); i+=2) {
				text +=  ", prep('" + args.get(i) + "', '"+ args.get(i+1) +"')";
			}
			text = "["+text +"], " + compText;
		}
		else {
			text += args.get(0) + "', '" + args.get(1) + "', '" + verb + "', '" + (negated? "no'":"yes'");
		}
		return text;
	}

}
