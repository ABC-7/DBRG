
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import ReqStructure.*;

public class RequirementsGeneration {
	

	public static ArrayList<ArrayList<Requirement>> generateRequirements(int senCount, int reqsCount, String senario, boolean multilevel) {//setting, String redundancy, boolean checking, Map<String, Integer> measures) {
		
		long t1, t2;
		ArrayList<ArrayList<Requirement>> reqs = new ArrayList<ArrayList<Requirement>>();
		
		System.out.println("Requirements generation through Prolog...");
		for (int i = 0; i < senCount; i++) {
			ArrayList<Requirement> temp = PrologQuery.generateComponentsBasedRequirements(reqsCount, senario, multilevel);
			reqs.add(temp);
		}
			
	
		//return PrologQuery.generateComponentsBasedRequirements(count, senario);
//		//Step1: generate random requirement based components 
//		ArrayList<ArrayList<ReqComponent>> comps = PrologQuery.generateComponentsBasedRequirements(count, setting, redundancy, measures);
//		System.out.println("=============================================");
//		
//		//Step2: adjust tense for each component
		System.out.println("Realisation...");
		ArrayList<ArrayList<Requirement>>  adjustedRequirements= (ArrayList<ArrayList<Requirement>>) reqs.parallelStream().map(object -> {
            return adjustTenses(object);
            }).collect(Collectors.toList());
		System.out.println("Completed");
		System.out.println("=============================================");

		return adjustedRequirements;
	}
	
	private static ArrayList<Requirement> adjustTenses(ArrayList<Requirement> reqs) {
		ArrayList<Requirement> res = new ArrayList<Requirement>();
		for (Requirement requirement : reqs) 
			res.add(adjustComponentTennse(requirement));
			
		return res;
	} 
	
	private static Requirement adjustComponentTennse(Requirement req) {
		//Step1: prepare sentence arguments
		String oldVerb, newVerb, newSlotText, complement, oldCompPortion, newCompPortion;
		
		
		for (ReqComponent comp : req.getComponents()) {
			
			//verb is the last argument
			oldVerb = comp.getVerb();//crrSubComponent.getSlotArgs().get(crrSubComponent.getSlotArgs().size()-1);
			String subj = comp.getSubj(); //.Utility.removeDefectedSpaces(crrSubComponent.getSlotArgs().get(crrSubComponent.getSlotArgs().size()-2)).replace(".", "");
			complement = comp.getComplement();
			
				//case action
				if(comp.isAction()) {
					
					//String passiveSubj = comp.getSubj(); //.Utility.removeDefectedSpaces(crrSubComponent.getSlotArgs().get(crrSubComponent.getSlotArgs().size()-2)).replace(".", "");
					//complement = comp.getComplement(); //args[1].replace(".", " ").replace(passiveSubj, "");
					newSlotText = SimpleNLG.getPassiveTense(subj, oldVerb, complement);
		
				}
				else {
					newSlotText = SimpleNLG.generateSingularPresentSentence(oldVerb, subj, complement).replace(".", " ");
						
				}
				newSlotText = newSlotText.substring(0, 1).toLowerCase() + newSlotText.substring(1);
				newVerb = newSlotText.toLowerCase().replace(Utility.removeDefectedSpaces(subj.toLowerCase()), "").replace(Utility.removeDefectedSpaces(complement.toLowerCase()), "");
				newVerb = Utility.removeDefectedSpaces(newVerb);
				
				//update verb arg
				comp.setVerb(newVerb);
				
				
				
				//update component text
				String oldComp;
				if(comp.getArguments().size() == 2) 
					oldComp = subj + " " + oldVerb + " " + complement;
				else
					oldComp = comp.getCompText();
				
				comp.setCompText(newSlotText);
				req.setReqText(req.getReqText().replace(oldComp, comp.getCompText() +","));
		}
				
		return req;
	}
	
}
