import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.LongStream;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import ReqStructure.*;

import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.custom.ScrolledComposite;

public class MainUI {
	private static int compCount = 0, condPropCount = 0, trigPropCount = 0, actPropCount = 0, preCondScopePropCount = 0, actScopePropCount = 0;
	public static Map<String, Integer> measures;
	private static Text inDesc;
	private static Text outText;
	private static Text SenCount;
	private static Text reqCount;
	
	private static void intialise() {
		measures = new HashMap<String, Integer>();
		measures.put("PreconditionsScope", 0);
		measures.put("PreScope-HidConst", 0);
		measures.put("PreScope-VTime", 0);
		
		measures.put("Trigger", 0);
		measures.put("Trig-HidConst", 0);
		measures.put("Trig-VTime", 0);
		measures.put("Trig-InBetTime", 0);
		
		measures.put("Condition", 0);
		measures.put("Cond-HidConst", 0);
		measures.put("Cond-VTime", 0);
		measures.put("Cond-PreTime", 0);
		
		measures.put("Action", 0);
		measures.put("Act-HidConst", 0);
		measures.put("Act-VTime", 0);
		measures.put("Act-PreTime", 0);
		measures.put("Act-InBetTime", 0);
		
		measures.put("ActionScope", 0);
		measures.put("ActScope-HidConst", 0);
		measures.put("ActScope-VTime", 0);
		
	}
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		final ArrayList<ArrayList<Requirement>>generatedReq  = new ArrayList<ArrayList<Requirement>>();
		Display display = Display.getDefault();
		Shell shlCorg = new Shell();
		shlCorg.setSize(596, 600);
		shlCorg.setText("DBRG");
		
		//intialise();
		//Dependency.loadEnvironment();
		
		Group grpComponents = new Group(shlCorg, SWT.NONE);
		grpComponents.setText("Descriptive Level");
		grpComponents.setBounds(10, 10, 166, 86);
		
		Button btnInformalLevel = new Button(grpComponents, SWT.RADIO);
		btnInformalLevel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				reqCount.setEditable(btnInformalLevel.getSelection());
				reqCount.setEnabled(btnInformalLevel.getSelection());
			}
		});
		btnInformalLevel.setBounds(10, 10, 132, 18);
		btnInformalLevel.setText("Single Level");
		
		Button btnSemiformalLevel = new Button(grpComponents, SWT.RADIO);
		btnSemiformalLevel.setSelection(true);
		btnSemiformalLevel.setBounds(10, 34, 132, 18);
		btnSemiformalLevel.setText("Multi Level");
		
		
		Button btnExport = new Button(shlCorg, SWT.NONE);
		btnExport.setEnabled(false);
		btnExport.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog (shlCorg, SWT.SAVE);
				String [] filterNames = new String [] {"Image Files", "All Files (*)"};
				String [] filterExtensions = new String [] {"*.txt", "*"};
				String filterPath = "/";
				String platform = SWT.getPlatform();
				if (platform.equals("win32")) {
					filterNames = new String [] {"All Files (*)"};
					filterExtensions = new String [] {"*"};
					filterPath = "c:\\";
				}
				dialog.setFilterNames (filterNames);
				dialog.setFilterExtensions (filterExtensions);
				File f = new File("src/out/");
				dialog.setFilterPath (f.getAbsolutePath());
				dialog.setFileName ("myfile");
				String path = dialog.open ();
				System.out.println ("Save to: " + path);
				System.out.println ("done");
				saveRequirements(generatedReq, path);
				System.out.println ("done");
			}
			
		});
		btnExport.setBounds(471, 25, 115, 63);
		btnExport.setText("Export");
		
		
		Button btnNewButton = new Button(shlCorg, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				intialise();
				String reqs = removeSpaces(inDesc.getText());
				reqs = "\"[" + reqs.replaceAll("inReq\\(", ",inReq(") + "]\"";
				reqs = reqs.replace("[,inReq(", "[inReq(");
				String res = "";
				//generatedReq = new ArrayList<ArrayList<Requirement>>();
				generatedReq.clear();
			
				int size = Integer.valueOf(SenCount.getText());
				int reqsCount = 0;
				if(btnInformalLevel.getSelection())
						reqsCount = Integer.valueOf(reqCount.getText());
				while (size != 0) {
					if(size > 1000) {
						generatedReq.addAll( RequirementsGeneration.generateRequirements(1000, reqsCount, reqs, btnSemiformalLevel.getSelection()));//, boolToIntToString(btnAllowRedundancy.getSelection()), btnEnableChecking.getSelection(), measures));
						size -= 1000;
					}
					else {
						generatedReq.addAll( RequirementsGeneration.generateRequirements(size, reqsCount, reqs, btnSemiformalLevel.getSelection()));//, boolToIntToString(btnAllowRedundancy.getSelection()), btnEnableChecking.getSelection(), measures));
						size = 0;
					}
				}
				String out ="";
				int i = 1;
				for (ArrayList<Requirement> r : generatedReq) {
					out += "Senario:"+i+"\n";
					for (Requirement t: r) {
						
						out += "ReqText: " +t.getReqText() + "\n" + "ReqBreakdowns:  "+ t.toString() + "\n---\n";
					}
					out += "==============================\n";
					i++;
				}
				//res = res.replaceAll("inReq\\(", "\ninReq(");
//				size = Integer.valueOf(count.getText());
//				res = res.substring(1);
//				String []list = res.split("\n");
//				
//				
//				for(int j = 0; j< list.length; ) {
//					out += "Senario:"+i+"\n";
//					for (int k = 0; k < size; k++) {
//						out += list[j+k] + "\n";
//					}
//					//out += list[j] + "\n" + list[j+1] + "\n" + list[j+2] + "\n";
//					i++;
//					
//					j= j+size;
//				}
						
				outText.setText(out);
				btnExport.setEnabled(true);
				//saveRequirements(generatedReq);
			}
		});
		btnNewButton.setBounds(194, 23, 148, 68);
		btnNewButton.setText("Start Generation");
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(shlCorg, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setAlwaysShowScrollBars(true);
		scrolledComposite.setBounds(10, 146, 576, 96);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		inDesc = new Text(scrolledComposite, SWT.BORDER | SWT.WRAP | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.MULTI);
		scrolledComposite.setContent(inDesc);
		scrolledComposite.setMinSize(inDesc.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		Label lblInputDescription = new Label(shlCorg, SWT.NONE);
		lblInputDescription.setBounds(25, 126, 117, 14);
		lblInputDescription.setText("Input Description");
		
		ScrolledComposite scrolledComposite_1 = new ScrolledComposite(shlCorg, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite_1.setAlwaysShowScrollBars(true);
		scrolledComposite_1.setBounds(10, 268, 576, 300);
		scrolledComposite_1.setExpandHorizontal(true);
		scrolledComposite_1.setExpandVertical(true);
		
		outText = new Text(scrolledComposite_1, SWT.BORDER | SWT.WRAP | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL);
		scrolledComposite_1.setContent(outText);
		scrolledComposite_1.setMinSize(outText.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		Label lblGeneratedScenarios = new Label(shlCorg, SWT.NONE);
		lblGeneratedScenarios.setText("Generated Scenarios");
		lblGeneratedScenarios.setBounds(25, 248, 117, 14);
		
		SenCount = new Text(shlCorg, SWT.BORDER);
		SenCount.setBounds(522, 106, 64, 19);
		
		Label lblRequirementsCount = new Label(shlCorg, SWT.NONE);
		lblRequirementsCount.setBounds(434, 109, 98, 14);
		lblRequirementsCount.setText("Senarios Count");
		
		Label lblRequirementsCount_1 = new Label(shlCorg, SWT.NONE);
		lblRequirementsCount_1.setText("Requirements Count");
		lblRequirementsCount_1.setBounds(228, 109, 119, 14);
		
		reqCount = new Text(shlCorg, SWT.BORDER);
		reqCount.setEnabled(false);
		reqCount.setEditable(false);
		reqCount.setBounds(346, 106, 64, 19);
		
		Button btnRefresh = new Button(shlCorg, SWT.NONE);
		btnRefresh.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				reqCount.setText("");
				SenCount.setText("");
				inDesc.setText("");
				outText.setText("");
				btnSemiformalLevel.setSelection(true);
				reqCount.setEnabled(false);
				reqCount.setEditable(false);
				btnExport.setEnabled(false);
				generatedReq.clear();
			}
		});
		btnRefresh.setText("Refresh");
		btnRefresh.setBounds(350, 25, 115, 63);
				
		shlCorg.open();
		shlCorg.layout();
		while (!shlCorg.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	protected static String removeSpaces(String text) {
		text = text.replaceAll("\\s+", " ");
		text = text.replaceAll("(\n)+", "\n");
		if(text.startsWith(" ")||text.startsWith("\n"))
			text = text.substring(1);
		if(text.endsWith(" ")||text.endsWith("\n"))
			text = text.substring(0, text.length()-1);
			
		return text;
	}
	
	
	public static void saveRequirements(ArrayList<ArrayList<Requirement>> requirements, String path) {
		int testi = 1;
		path = path.substring(0, path.length()-4);
		ArrayList<String> res = new ArrayList<String>();
		for (ArrayList<Requirement> req : requirements) {
			for (Requirement r : req) {
				
				String ttt = "Req-"+r.getId()+": ";
				ttt += r.getReqText()+"\n\n[\n";
				
				ttt += r.toString();
				ttt += "\n]\n===========================================\n";
				
				res.add(ttt);
				ttt = "";
			}
			testi++;
			Utility.writeToFile(path + "Sen" + testi + ".txt", res);
		}
		
		//Utility.writeToFile("src/GenReqOut.txt", res);
		
	}
}
